const Market = require("../model/marketModel");

exports.getAllList = async (req, res) => {
	Market.find({})
		.then((response) => {
			res.json({
				data: response,
			});
		})
		.catch((err) => {
			res.json({
				message: err,
			});
		});
};

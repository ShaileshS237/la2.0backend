const Market = require("../model/bajarbhavModel");

exports.getAllMarketPrice = async (req, res) => {
	Market.find()
		.then((bajarbhav) => {
			res.json({
				data: bajarbhav,
			});
		})
		.catch((err) => {
			res.json({
				message: err,
			});
		});
};

const mongoose = require("mongoose");

let marketSchema = new mongoose.Schema({
	_id: mongoose.Schema.Types.ObjectId,
	image: {
		type: String,
		required: false,
	},
	title: {
		type: String,
		required: true,
	},
	title_marathi: {
		type: String,
		required: true,
	},
	link: {
		type: String,
		required: true,
	},
});

let marketListSchema = new mongoose.Schema({
	_id: mongoose.Schema.Types.ObjectId,
	image: {
		type: String,
		required: false,
	},
	name: {
		type: String,
		required: true,
	},
	description: {
		type: String,
		required: true,
	},
	mobile: {
		type: String,
		required: true,
	},
	mobile: {
		type: String,
		required: true,
	},
	whatsappno: {
		type: String,
		required: true,
	},
	openTime: {
		type: String,
	},
	closeTime: {
		type: String,
	},
	address: {
		type: String,
		required: true,
	},
	closedOn: {
		type: String,
	},
	category: {
		type: String,
		required: true,
	},
});

module.exports = mongoose.model("market", marketSchema);

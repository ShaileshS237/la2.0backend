const express = require("express");
const router = express.Router();
const marketController = require("../controller/marketController");

router.get("/", marketController.getAllList);

module.exports = router;

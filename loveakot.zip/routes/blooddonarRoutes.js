const express = require("express");
const router = express.Router();
const blooddonarController = require("../controller/blooddonarController");


router.route("/").get(blooddonarController.getBloodDonar);
router.route("/:id").get(blooddonarController.getBloodDonar);

module.exports = router;
